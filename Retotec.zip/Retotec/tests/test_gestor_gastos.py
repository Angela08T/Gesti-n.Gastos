import unittest
from gestor_gastos import GestorGastos
from gasto import Gasto

class TestGestorGastos(unittest.TestCase):
    def setUp(self):
        self.gestor = GestorGastos()
        self.gasto = Gasto("Comida", "Almuerzo", "2023-10-15", 20.50)

    def test_agregar_gasto(self):
        self.gestor.agregar_gasto(self.gasto)
        self.assertEqual(len(self.gestor.listar_gastos()), 1)

    def test_eliminar_gasto(self):
        self.gestor.agregar_gasto(self.gasto)
        self.gestor.eliminar_gasto(0)
        self.assertEqual(len(self.gestor.listar_gastos()), 0)

    def test_filtrar_gastos_por_mes(self):
        self.gestor.agregar_gasto(self.gasto)
        gasto_filtrados = self.gestor.filtrar_gastos_por_mes("10")
        self.assertEqual(len(gasto_filtrados), 1)

if __name__ == "__main__":
    unittest.main()

